SCILAB LAB PROGRAMS

Experiment 01: Functions

Each exercise is saved as a separate Scilab script (.sce) file.
Open a file in Scilab and click Execute, or run it from the Scilab console
using exec("full_path_to_file.sce").

Files:
1. Factorial Using Function
2. Prime Number Using Function
3. Largest of Three Using Function
4. Student Grade Using Function
5. Fibonacci Series Using Function

The programs have been formatted for readability. Their original logic is preserved.
